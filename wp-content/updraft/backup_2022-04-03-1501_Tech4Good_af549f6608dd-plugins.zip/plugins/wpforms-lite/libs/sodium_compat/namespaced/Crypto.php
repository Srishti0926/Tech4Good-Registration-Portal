<?php
namespace ParagonIE\Sodium;

class Crypto extends \ParagonIE_Sodium_Crypto
{

}
